<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "comentarios_db");

if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}
?>