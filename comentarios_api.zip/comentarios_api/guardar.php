<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "comentarios_db");

if ($conn->connect_error) {
  echo json_encode(["error" => "Error de conexión"]);
  exit;
}

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
  echo json_encode(["error" => "No llegaron datos"]);
  exit;
}

$usuario = isset($data['usuario']) ? $data['usuario'] : 'Tú';
$mensaje = isset($data['mensaje']) ? $data['mensaje'] : '';

if ($mensaje === '') {
  echo json_encode(["error" => "Mensaje vacío"]);
  exit;
}

$usuario = $conn->real_escape_string($usuario);
$mensaje = $conn->real_escape_string($mensaje);

$sql = "INSERT INTO comentarios (usuario, mensaje) VALUES ('$usuario', '$mensaje')";

if ($conn->query($sql)) {
  echo json_encode(["success" => true]);
} else {
  echo json_encode(["error" => $conn->error]);
}

$conn->close();
?>