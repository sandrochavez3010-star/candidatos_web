<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "comentarios_db");

if ($conn->connect_error) {
  die("Error de conexión");
}

$sql = "SELECT usuario, mensaje FROM comentarios ORDER BY id DESC";
$result = $conn->query($sql);

$comentarios = [];

while($row = $result->fetch_assoc()) {
  $comentarios[] = $row;
}

echo json_encode($comentarios);

$conn->close();
?>